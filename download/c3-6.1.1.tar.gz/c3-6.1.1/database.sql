-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016-11-17 04:53:55
-- 服务器版本: 5.5.52-0ubuntu0.14.04.1
-- PHP 版本: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `hellodb`
--
CREATE DATABASE IF NOT EXISTS `hellodb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `hellodb`;

-- --------------------------------------------------------

--
-- 表的结构 `c3_auto_increment`
--

DROP TABLE IF EXISTS `c3_auto_increment`;
CREATE TABLE IF NOT EXISTS `c3_auto_increment` (
  `c3_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`c3_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6997802582 ;

-- --------------------------------------------------------

--
-- 表的结构 `c3_modules`
--

DROP TABLE IF EXISTS `c3_modules`;
CREATE TABLE IF NOT EXISTS `c3_modules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `lang` varchar(8) NOT NULL DEFAULT 'php',
  `dep` varchar(1024) NOT NULL,
  `ver` int(11) NOT NULL DEFAULT '1',
  `code` text NOT NULL,
  `syscode` varchar(32) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '4',
  `user` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `syscode` (`syscode`),
  KEY `ver` (`ver`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

-- --------------------------------------------------------

--
-- 表的结构 `c3_tmp_clean_task`
--

DROP TABLE IF EXISTS `c3_tmp_clean_task`;
CREATE TABLE IF NOT EXISTS `c3_tmp_clean_task` (
  `taskid` bigint(20) unsigned NOT NULL,
  `taskkey` varchar(32) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`taskid`),
  UNIQUE KEY `taskkey` (`taskkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `c3_tmp_node`
--

DROP TABLE IF EXISTS `c3_tmp_node`;
CREATE TABLE IF NOT EXISTS `c3_tmp_node` (
  `nid` int(11) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `c3_tmp_url_alias`
--

DROP TABLE IF EXISTS `c3_tmp_url_alias`;
CREATE TABLE IF NOT EXISTS `c3_tmp_url_alias` (
  `xnid` int(11) NOT NULL,
  `src` varchar(128) NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `index_xnid` (`xnid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `callbackruntimes`
--

DROP TABLE IF EXISTS `callbackruntimes`;
CREATE TABLE IF NOT EXISTS `callbackruntimes` (
  `cbrtid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taskid` bigint(20) unsigned NOT NULL,
  `runtime` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `taskcondition` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hookid` bigint(20) unsigned NOT NULL,
  `hookpayload` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `pullnode` varchar(32) NOT NULL DEFAULT '',
  `timestamp` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`cbrtid`),
  KEY `pullnode` (`pullnode`,`timestamp`),
  KEY `runtime` (`runtime`),
  KEY `index_timestamp` (`timestamp`),
  KEY `index_taskid` (`taskid`),
  KEY `index_hookid` (`hookid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6997766781 ;

-- --------------------------------------------------------

--
-- 表的结构 `callbacks`
--

DROP TABLE IF EXISTS `callbacks`;
CREATE TABLE IF NOT EXISTS `callbacks` (
  `callbackid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `srcid` bigint(20) unsigned NOT NULL,
  `srcruntime` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `srcspec` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `taskid` bigint(20) unsigned NOT NULL,
  `runtime` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `taskcondition` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`callbackid`),
  KEY `hookid` (`srcid`),
  KEY `runtime` (`runtime`),
  KEY `srcspec` (`srcspec`(255)),
  KEY `archived` (`archived`),
  KEY `taskid` (`taskid`),
  KEY `srcruntime` (`srcruntime`),
  KEY `condition` (`taskcondition`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6997763563 ;

-- --------------------------------------------------------

--
-- 表的结构 `dueruntimes`
--

DROP TABLE IF EXISTS `dueruntimes`;
CREATE TABLE IF NOT EXISTS `dueruntimes` (
  `taskid` bigint(20) unsigned NOT NULL,
  `runtime` varchar(32) CHARACTER SET latin1 NOT NULL,
  `dueid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`dueid`),
  UNIQUE KEY `taskid` (`taskid`),
  KEY `runtime` (`runtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `hookruntimes`
--

DROP TABLE IF EXISTS `hookruntimes`;
CREATE TABLE IF NOT EXISTS `hookruntimes` (
  `hookrtid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `runtime` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `taskcondition` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hookrtname` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `hookrteval` varchar(3096) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hookrtid`),
  KEY `runtime` (`runtime`,`taskcondition`(255)),
  KEY `hookrtname` (`hookrtname`(255))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `hooks`
--

DROP TABLE IF EXISTS `hooks`;
CREATE TABLE IF NOT EXISTS `hooks` (
  `hookid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `src` bigint(20) unsigned NOT NULL,
  `spec` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `result` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `runtime` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`hookid`),
  KEY `spec` (`spec`(255)),
  KEY `runtime` (`runtime`),
  KEY `updated` (`updated`),
  KEY `runtime_2` (`runtime`),
  KEY `src` (`src`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6997779199 ;

-- --------------------------------------------------------

--
-- 表的结构 `hooks_t`
--

DROP TABLE IF EXISTS `hooks_t`;
CREATE TABLE IF NOT EXISTS `hooks_t` (
  `htid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tkey` varchar(32) CHARACTER SET latin1 NOT NULL,
  `timestamp` float NOT NULL,
  PRIMARY KEY (`htid`),
  UNIQUE KEY `tkey` (`tkey`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `maps`
--

DROP TABLE IF EXISTS `maps`;
CREATE TABLE IF NOT EXISTS `maps` (
  `mapid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taskkey` varchar(32) CHARACTER SET latin1 NOT NULL,
  `runtime` varchar(32) CHARACTER SET latin1 NOT NULL,
  `spec` varchar(256) CHARACTER SET latin1 NOT NULL,
  `mr` varchar(256) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`mapid`),
  KEY `taskkey` (`taskkey`,`spec`),
  KEY `runtime` (`runtime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- 表的结构 `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `pageid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `html` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `contenttype` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`pageid`),
  KEY `url` (`url`(255)),
  KEY `contenttype` (`contenttype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6997779254 ;

-- --------------------------------------------------------

--
-- 表的结构 `reduces`
--

DROP TABLE IF EXISTS `reduces`;
CREATE TABLE IF NOT EXISTS `reduces` (
  `reduceid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taskkey` varchar(32) CHARACTER SET latin1 NOT NULL,
  `runtime` varchar(32) CHARACTER SET latin1 NOT NULL,
  `mapid` int(11) NOT NULL,
  PRIMARY KEY (`reduceid`),
  KEY `taskkey` (`taskkey`,`runtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `runtimegroup`
--

DROP TABLE IF EXISTS `runtimegroup`;
CREATE TABLE IF NOT EXISTS `runtimegroup` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rgid` int(11) NOT NULL,
  `runtime` varchar(32) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `rgid` (`rgid`,`runtime`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

-- --------------------------------------------------------

--
-- 表的结构 `runtimes`
--

DROP TABLE IF EXISTS `runtimes`;
CREATE TABLE IF NOT EXISTS `runtimes` (
  `rid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `runtime` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `taskid` bigint(20) unsigned NOT NULL,
  `name` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `maillog` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `mode` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cost` bigint(20) NOT NULL DEFAULT '0',
  `updated` datetime DEFAULT NULL,
  `retries` int(11) NOT NULL,
  `completed` datetime DEFAULT NULL,
  `archived` tinyint(1) NOT NULL,
  `priority` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `next_eval` datetime DEFAULT NULL,
  `ctype` varchar(8) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`rid`),
  UNIQUE KEY `runtime` (`runtime`),
  KEY `taskid` (`taskid`),
  KEY `updated` (`updated`),
  KEY `archived` (`archived`,`next_eval`,`priority`),
  KEY `next_eval` (`next_eval`),
  KEY `priority` (`priority`),
  KEY `mode` (`mode`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6997779200 ;

-- --------------------------------------------------------

--
-- 表的结构 `sparkevents`
--

DROP TABLE IF EXISTS `sparkevents`;
CREATE TABLE IF NOT EXISTS `sparkevents` (
  `spark_eventid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `spark_timestamp` float NOT NULL DEFAULT '0',
  `hbase_catalog` varchar(128) NOT NULL,
  `hbase_baseid` bigint(20) unsigned NOT NULL,
  `hbase_json` mediumtext CHARACTER SET utf8 NOT NULL,
  `pullnode` varchar(32) NOT NULL,
  PRIMARY KEY (`spark_eventid`),
  KEY `spark_timestamp` (`spark_timestamp`,`hbase_catalog`,`hbase_baseid`),
  KEY `pullnode` (`pullnode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6997802582 ;

-- --------------------------------------------------------

--
-- 表的结构 `tasklogs`
--

DROP TABLE IF EXISTS `tasklogs`;
CREATE TABLE IF NOT EXISTS `tasklogs` (
  `logid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taskid` bigint(20) unsigned NOT NULL,
  `log` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `runtime` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`logid`),
  KEY `taskid` (`taskid`),
  KEY `runtime` (`runtime`),
  KEY `level` (`level`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6997802583 ;

-- --------------------------------------------------------

--
-- 表的结构 `tasknodes`
--

DROP TABLE IF EXISTS `tasknodes`;
CREATE TABLE IF NOT EXISTS `tasknodes` (
  `tnid` int(11) NOT NULL AUTO_INCREMENT,
  `taskkey` varchar(32) CHARACTER SET latin1 NOT NULL,
  `nid` int(11) NOT NULL,
  PRIMARY KEY (`tnid`),
  UNIQUE KEY `taskkey` (`taskkey`),
  KEY `nid` (`nid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=282 ;

-- --------------------------------------------------------

--
-- 表的结构 `tasknodes_service`
--

DROP TABLE IF EXISTS `tasknodes_service`;
CREATE TABLE IF NOT EXISTS `tasknodes_service` (
  `taskkey` varchar(32) CHARACTER SET latin1 NOT NULL,
  `nid` int(11) NOT NULL,
  PRIMARY KEY (`taskkey`),
  KEY `nid` (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `taskid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taskkey` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `archived` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime DEFAULT NULL,
  `tkey` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`taskid`),
  KEY `taskkey` (`taskkey`),
  KEY `index_tasks_created` (`created`),
  KEY `tkey` (`tkey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6997779187 ;

-- --------------------------------------------------------

--
-- 表的结构 `tasksessions`
--

DROP TABLE IF EXISTS `tasksessions`;
CREATE TABLE IF NOT EXISTS `tasksessions` (
  `sessionid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taskid` bigint(20) unsigned NOT NULL,
  `spec` varchar(256) CHARACTER SET latin1 NOT NULL,
  `accesskey` varchar(32) CHARACTER SET latin1 NOT NULL,
  `expired` datetime NOT NULL,
  `op` varchar(8) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`sessionid`),
  KEY `taskid` (`taskid`,`spec`),
  KEY `expired` (`expired`),
  KEY `op` (`op`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `tokens`
--

DROP TABLE IF EXISTS `tokens`;
CREATE TABLE IF NOT EXISTS `tokens` (
  `tokenid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tkey` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tokenid`),
  KEY `key` (`tkey`(255))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6612403258 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
