queued_status
c3://2212af11aad311e69b89902b34399a93.dtg

---------------------------------------------------------------
fixed pika==0.9.14

pika/adapters/blocking_connection.py

-1098 if reply in replies:
+1098 if reply in replies and self._frames.get(reply):

Minimal Kernel
---------------------------------------------------------------
sudo apt-get install MySQL-Python
sudo apt-get install libxml2-dev libxslt-dev
sudo ln -s /usr/include/libxml2/libxml   /usr/include/libxml

pika==0.9.14
paramiko
lxml
croniter
kafka
tornado

Normal Kernel
---------------------------------------------------------------
cython
amqplib
backports_abc
bcrypt
certifi
cffi
chardet
croniter
crypto
cryptography
dateutil
enum
geoip2
happybase
idna
ipaddress
kafka
kazoo
lxml
maxminddb
MySQL_python
MySQLdb
Naked
paramiko
pika==0.9.14
pip
ply
pyasn1
pycparser
pymysql
python_dateutil
PyYAML
requests
setuptools
shellescape
singledispatch
six
thrift
thriftpy
tornado
yaml