#-*- coding: utf-8 -*-
#!/usr/bin/env python
"""
        *   @conby C3 Computing Platform code, v6.1.1
        *
        *   Copyright 2004-2011 @conby C3 development team <support@conby.com>
        *
        *   Licensed under the Apache License, Version 2.0 (the "License");
        *   you may not use this file except in compliance with the License.
        *   You may obtain a copy of the License at
        *
        *       http://www.apache.org/licenses/LICENSE-2.0
        *
        *   Unless required by applicable law or agreed to in writing, software
        *   distributed under the License is distributed on an "AS IS" BASIS,
        *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        *   See the License for the specific language governing permissions and
        *   limitations under the License.

"""
import sys
import time

version = '0.010'

MYSQLHOST = 'localhost'
MYSQLUSER = 'root'
MYSQLPASSWD = '12345678'
MYSQLDB = 'hellodb'
#MYSQL_SOCK='/home/hello/data/temp/mysql.sock'
MYSQL_SOCK=''
MYSQL_REPLUSER = 'root'
MYSQL_REPLPASSWD = '12345678'
MYSQL_REPL_SERVER_ID = 1

BACKEND_MODE = True
NATIVE_MODE = 'run'

TOKEN_SECRET = 'f89568f2fcaf11e58887e84e061e3583'
ENABLE_DNN = False
ENABLE_MT_SPIDER = False
KAFKA_BATCH = 3000
KAFKA_STAT_INTERVAL = 60
KAFKA_SEND_INTERVAL = 10
KAFKA_MAX_MESSAGE_SIZE = 1048576
TASKLOGS_ENABLE = True
TASKLOGS_LIMIT = 100000
PAGES_LIMIT = 10000
LOG_REPORT_LENGTH = 100
RUNTIME_STEP_LENGTH = 1000
CALLBACK_STEP_LENGTH = 1000
CALLBACK_STEP_TIMEOUT = 60*60
AUTOCLEAN_STEP_LENGTH = 50
AUTOIDCLEAN_STEP_LENGTH = 5000
HOOK_EVENT_TIMEOUT = 120
ACTION_REQ_TIMEOUT = 12
C3_MAX_RETRIES = 3
G_LOCK_TIMEOUT = 8
G_LOCK_ALIVE = 120
MAX_QMSG_COUNT = 8*10000

HTTPD_STATUS_URL = "https://comatrix:8082/server-status"
HTTPD_BASE_PATH = '/home/hello/data/httpd-2.4.18'
HTTPD_CLOSING_PERCENT = 0.6

C3_ADMIN = 'admin'
C3_SMTP_TIMEOUT = 30
C3_SMTP_HOST = "www.conby.com"
C3_SMTP_PORT = 25
C3_SMTP_UID = "support@conby.com"
C3_SMTP_PWD = "12345678"
C3_SMTP_SENDER = "support@conby.com"
C3_SMTP_REPLYTO = "conby@189.cn"

C3_WECHAT_APPID = 'wxd57400fa6b18006c'
C3_WECHAT_APPSECRET = '7503598445d1f8bde8e1e2b2de633ac9'
C3_WECHAT_INKEY = 'abcdefg'
C3_HIVE_TASKKEY = 'f89568f2fcaf11e58887e84e061e3583'
C3_HIVE_SPEC = 'out'
C3_HIVE_INKEY = 'abc123pp'
C3_SPARK_TASKKEY = '935f60bcfa5411e59858e84e061e3583'
C3_SPARK_SPEC = 'out'
C3_SPARK_INKEY = 'abc123pp'
C3_SPARK_CODEBASE = 'hdfs://comatrix/user/hello/'
C3_HBASE_IGNORE = [
                      ['c3_auto_increment','delete'],
                      ['c3_auto_increment','write'],
                      ['c3_auto_increment','update'],
                      ['tasklogs','delete'],
                      ['pages','delete'],
                      ['callbackruntimes','delete'],
                      ['sparkevents','delete'],
                  ]
C3_HBASE_HOST = "comatrix"
C3_HBASE_TABLE = "logs"
C3_HBASE_TABLES_MAP = {
                      '0':                  ['00',''],
                      '00':                 ['00',''],
                      'nginx':              ['01',''],
                      'filelogs':           ['02',''],
                      '0X':                 ['0X',''],
                      'events_in':          ['0X',''],
                      'c3_auto_increment':  ['0Z','c3_id'],
                      'A':                  ['0A','logid'],
                      'B':                  ['0B','pageid'],
                      'tasklogs':           ['0A','logid'],
                      'pages':              ['0B','pageid'],
                      'sparkevents':        ['0C','spark_eventid'],
                      'callbackruntimes':   ['0D','cbrtid'],
                      'watchdog':           ['0E','wid'],
                      'hooks':              ['0F','hookid'],
                      'runtimes':           ['0G','rid'],
                      'tasks':              ['0H','taskid'],
                      'c3_modules':         ['0I','id'],
                      'callbacks':          ['0J','callbackid'],
                      'dueruntimes':        ['0K','dueid'],
                      'hookruntimes':       ['0L','hookrtid'],
                      'hooks_t':            ['0M','htid'],
                      'maps':               ['0N','mapid'],
                      'reduces':            ['0O','reduceid'],
                      'runtimegroup':       ['0P','rid'],
                      'tasknodes':          ['0Q','tnid'],
                      'tasksessions':       ['0R','sessionid'],
                      'tokens':             ['0S','tokenid'],
                      'cache_rules':        ['0T',''],
                      'variable':           ['0U',''],
                      }
                          
SCHEMA_CATALOGS = {'fields': [
                              {'metadata': {}, 'type': 'string', 'name': 'hbase_catalog', 'nullable': False}, 
                              {'metadata': {}, 'type': 'string', 'name': 'hbase_key', 'nullable': False}
                             ], 'type': 'struct'}
                             
SCHEMA_NGINX = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'host', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'remote_addr', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'delimiter', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'remote_user', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'time_local', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'request', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'status', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'body_bytes_sent', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'http_referer', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'http_user_agent', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'http_x_forwarded_for', 'nullable': False}
                          ], 'type': 'struct'}        
                          
SCHEMA_HBASELOG2 = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'py', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_service_name', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_task_key', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'uu', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'task_owner_path', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_callback_type', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_callback_name', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_hook_callback', 'nullable': False}
                          ], 'type': 'struct'}       
                          
SCHEMA_HOOKS = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'hookid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'src', 'nullable': False},                            
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'spec', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'result', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'updated', 'nullable': False}
                          ], 'type': 'struct'}      
                          
SCHEMA_PAGES = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'pageid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'contenttype', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'url', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'html', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'updated', 'nullable': False}
                          ], 'type': 'struct'}           
                          
SCHEMA_TASKS = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'taskid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'taskkey', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'description', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'tkey', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'archived', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'updated', 'nullable': True}
                          ], 'type': 'struct'}  
                          
SCHEMA_SPARKEVENTS = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'spark_eventid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'pullnode', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'hbase_json', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'hbase_baseid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'spark_timestamp', 'nullable': False}
                          ], 'type': 'struct'}        
                          
SCHEMA_RUNTIMES = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'rid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'name', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'taskid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'mode', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'maillog', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'description', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'type', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'ctype', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'archived', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'cost', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'priority', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'retries', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'next_eval', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'completed', 'nullable': True}, 
                           {'metadata': {}, 'type': 'long', 'name': 'updated', 'nullable': False}
                          ], 'type': 'struct'}  
                          
SCHEMA_CALLBACKRUNTIMES = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'cbrtid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'long', 'name': 'hookid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'taskid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'pullnode', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'hookpayload', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'taskcondition', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'timestamp', 'nullable': False}
                          ], 'type': 'struct'}          
                          
SCHEMA_CALLBACKS = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'callbackid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'long', 'name': 'taskid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'taskcondition', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'srcid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'srcruntime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'srcspec', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'archived', 'nullable': False}
                          ], 'type': 'struct'}                                 
                          
SCHEMA_EVENTS_IN = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'message_id', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'task_key', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'task_owner_path', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'access_key', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'action_spec', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'body', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'lang', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'mode', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 't_key', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'retry', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'updated', 'nullable': False}
                          ], 'type': 'struct'}      
                          
SCHEMA_TASKLOGS = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'logid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'taskid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'log', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'level', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'updated', 'nullable': False}
                          ], 'type': 'struct'}                                                                                                                                                                                                                                 

SCHEMA_TOKENS = {'fields': [
                           {'metadata': {}, 'type': 'long', 'name': 'tokenid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'tkey', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'content', 'nullable': False}
                          ], 'type': 'struct'} 
                          
SCHEMA_VARIABLE = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'name', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'value', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}          
                          
SCHEMA_WATCHDOG = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'wid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'hostname', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'link', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'location', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'message', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'referer', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'type', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'variables', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'uid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'severity', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'timestamp', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}             
                          
SCHEMA_CACHE = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'cid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'headers', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'data', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'expire', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'serialized', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}    
                          
SCHEMA_CACHE_RULES = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'cid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'headers', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'data', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'expire', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'serialized', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}                              
                          
SCHEMA_SESSIONS = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'sid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'hostname', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'session', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'uid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'cache', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'timestamp', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}        
                          
SCHEMA_C3_TMP_CLEAN_TASK = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'taskkey', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'taskid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}               
                          
SCHEMA_C3_TMP_USERS = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'name', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'uid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'long', 'name': 'count', 'nullable': False},      
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}                                                       
                          
SCHEMA_CACHE_MENU = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'cid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'headers', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'data', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'expire', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'serialized', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}       
                          
SCHEMA_CACHE_FILTER = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'cid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'headers', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'data', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'expire', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'serialized', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}       
                          
SCHEMA_CACHE_FORM = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'cid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'headers', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'data', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'expire', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'serialized', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}                                                        
                          
SCHEMA_CACHE_HISTORY = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'nid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'uid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'long', 'name': 'timestamp', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}          
                          
SCHEMA_HISTORY = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'nid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'uid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'long', 'name': 'timestamp', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}      
                          
SCHEMA_USERS = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'uid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'name', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'init', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'mail', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'language', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'pass', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'picture', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'signature', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'theme', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'timezone', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'data', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'status', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'signature_format', 'nullable': False},   
                           {'metadata': {}, 'type': 'integer', 'name': 'mode', 'nullable': False},   
                           {'metadata': {}, 'type': 'integer', 'name': 'sort', 'nullable': False},   
                           {'metadata': {}, 'type': 'integer', 'name': 'threshold', 'nullable': False},   
                           {'metadata': {}, 'type': 'long', 'name': 'login', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'access', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}                         
                          
SCHEMA_NODE_REVISIONS = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'nid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'vid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'uid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'timestamp', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'title', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'format', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'log', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'body', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'teaser', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}      
                          
SCHEMA_NODE = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'nid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'vid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'uid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'created', 'nullable': False},
                           {'metadata': {}, 'type': 'long', 'name': 'changed', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'title', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'status', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'type', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'language', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'moderate', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'promote', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'comment', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'sticky', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'tnid', 'nullable': False},
                           {'metadata': {}, 'type': 'integer', 'name': 'translate', 'nullable': False},
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}     
                          
SCHEMA_TASKNODES = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'tnid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'nid', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'taskkey', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}    
                          
SCHEMA_URL_ALIAS = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'src', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'dst', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'language', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'pid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}      
                          
SCHEMA_NODE_COMMENT_STATISTICS = {'fields': [
                           {'metadata': {}, 'type': 'integer', 'name': 'nid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'last_comment_name', 'nullable': True},                    
                           {'metadata': {}, 'type': 'integer', 'name': 'last_comment_uid', 'nullable': False}, 
                           {'metadata': {}, 'type': 'long', 'name': 'last_comment_timestamp', 'nullable': False}, 
                           {'metadata': {}, 'type': 'integer', 'name': 'comment_count', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'sql_event', 'nullable': False}
                          ], 'type': 'struct'}                                                                                                                                                                                                                                                                                                                              
                          
SCHEMA_FILELOGS = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'host', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'date', 'nullable': True},                    
                           {'metadata': {}, 'type': 'string', 'name': 'time', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'label', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'log', 'nullable': False}
                          ], 'type': 'struct'}
                          
SCHEMA_WECHAT = {'fields': [
                           {'metadata': {}, 'type': 'string', 'name': 'c3_callback_name', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_callback_type', 'nullable': False},                    
                           {'metadata': {}, 'type': 'string', 'name': 'c3_hook_callback', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_service_name', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'c3_task_key', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'py', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'runtime', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'task_owner_path', 'nullable': False}, 
                           {'metadata': {}, 'type': 'string', 'name': 'xml', 'nullable': False}
                          ], 'type': 'struct'}                          
                          
NGINX_LOG_FILES = ['/home/hello/data/nginx-1.9.9/log/www_access_443.log','/home/hello/data/nginx-1.9.9/log/api_access_443.log','/home/hello/data/c3-5.0.1/nohup.out']
NGINX_LOG_DOMAINS = ['www.conby.com','api.conby.com','c3log']

C3_BASE_URL = "https://api.conby.com/c3/apiservice"
C3_BASE_URL_C3C = "https://api.conby.com/c3/apiservice.c3c"
C3_BASE_URL_CRON = "http://conby300.appspot.com/api.php"

# C3_BASE_URL_USER = "http://localhost/c3/apiservice"
C3_BASE_URL_USER = "https://api.conby.com/c3/apiservice"
WEBHDFS_BASE_URL = 'http://comatrix:50070/webhdfs/v1/user/hello'

CA_KEY_PATH = 'CA/private/key.pem'
CA_CERTIFICATE_PATH = 'CA/cacert.pem'
C3_HTTP_PORT = "8081,8082"
C3_HTTPS_PORT = "8083"
C3_HTTP_SOCKET_TIMEOUT = 2
C3_HTTP_REQ_TIMEOUT = 30
C3_HTTP_TIMEOUT_AVG = 100
C3_HTTP_RATE_AVG = 100
C3_HTTP_CHANNELS_LIMIT = 10
C3_HTTP_REQ_QUEUES_DBG = 2
C3_HTTP_REQ_QUEUES_PLUS = 10
C3_HTTP_TH_SVR_MIN = 6
C3_HTTP_TH_SVR_MAX = 30
C3_HTTP_TH_SLEEP_COUNT = 12000
C3_TRANSACTION_TIMEOUT = 3600
C3_SP_CODE = ''
C3_SP_HOOK_MODE = ''   # c3web
C3_HTTP_URLOPEN_TIMEOUT = 30
C3_SPIDER_URLOPEN_TIMEOUT = 8
C3_RPC_TIMEOUT = 8
C3_PUBLIC_API = False
C3_HTTP_USER_AGENTS = [
        'Mozilla/5.0 (Windows; U; Windows NT 5.1; it; rv:1.8.1.11) Gecko/20071127 Firefox/2.0.0.11',
        'Opera/9.25 (Windows NT 5.1; U; en)',
        'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)',
        'Mozilla/5.0 (compatible; Konqueror/3.5; Linux) KHTML/3.5.5 (like Gecko) (Kubuntu)',
        'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.12) Gecko/20070731 Ubuntu/dapper-security Firefox/1.5.0.12',
        'Lynx/2.8.5rel.1 libwww-FM/2.14 SSL-MM/1.4.1 GNUTLS/1.2.9'
    ]

C3_LOG_FILES = [
        '/home/hello/data/c3-3.3.8/nohup.out',       
        '/home/hello/data/c3-3.3.8/nohup.out'
    ]

C3_SUBPROCESS_FLAGS = [
        '/usr/bin/python',
        '/usr/bin/free',
        '/home/hello/data/c3-3.3.8/runc3.py'
    ]

C3_HTTP_WEB_PROXIES = [
        # 'http://conby500.appspot.com/c3/apiservice',
        # 'http://conby501.appspot.com/c3/apiservice',
        # 'http://conby502.appspot.com/c3/apiservice',
        # 'http://conby503.appspot.com/c3/apiservice',
        # 'http://conby504.appspot.com/c3/apiservice',
        # 'http://conby505.appspot.com/c3/apiservice',
        'https://api.conby.com/c3/apiservice.c3c',
        # 'https://api.conby.com:8085/c3/apiservice.c3c'
    ]

C3_HTTP_WEB_PROXIES_LOCALDOMAINS = [
        'comatrix',
        'www.conby.com',
        'api.conby.com'
    ]

C3_PUBLIC_TOKEN_USERS = [
        '.84a',
        '.85a',
    ]

C3_SVR_VERSION = 'C3S/2.2'
C3_API_VERSION = 'API/3.5'

C3_ARPC_USING_DBO_CACHING = False

C3_KF_HOST = 'comatrix:9092'
C3_KF_TOPIC = 'hbase'
C3_KF_TOPIC_HIVE = 'hive'
C3_MQ_PROTOCOL = 0.91
C3_MQ_RECONNECT = False
C3_MQ_RECONNECT_MAX_RETRIES = 3
C3_MQ_SOCKET_TIMEOUT = 2
C3_MQ_HEARTBEAT_INTERVAL = 120
C3_MQ_HOST = 'www.conby.com:5672'
C3_MQ_VIRTUAL_HOST = 'c3'
C3_MQ_REALM = '/data'
C3_MQ_EXCHANGE_TAG = '_hub'
C3_MQ_QUEUE_TAG = '_queue'
C3_MQ_CLOCK_EXCHANGE = 'clock'
C3_MQ_USERID = 'hello'
C3_MQ_PASSWORD = '12345678'
C3_MQ_PREFETCH_SIZE = 10240
C3_MQ_PREFETCH_COUNT = 1
C3_MQ_QUEUE_INTERVAL = 0.001
C3_MQ_QSET_INTERVAL = 1
C3_MQ_CLOSE_EXCEPTION = False
C3_MQ_DEFAULT_CHANNEL_NUMBER = 0
C3_MQ_MSG_EXPIRATION = '1800000'
C3_MQ_SET2Q_SLEEP_MODE = True
C3_MQ_BACKPRESSURE_MULTIPLIER = 10
C3_MQ_QUEUE_MESSAGES_LIMIT = 5000
C3_MQ_QUEUES_TXT_BEGIN = 'Listing queues ...'
C3_MQ_QUEUES_TXT_END = '...done.'

MAX_IMAP_TIMEOUT = 30
MAX_IMAP_COUNT = 20
MAX_IMAP_MAIL_SIZE = 1024*1024
SEND_MAIL_MODE = 'native'

RES_1104_EN = 'rejected'
RES_1104_ZH = '被拒绝'
RES_1117_EN = 'update'
RES_1117_ZH = '更新'
RES_1141_EN = 'email event accepted'
RES_1141_ZH = '邮件 event 已接受'
RES_1442_EN = 'warning'
RES_1442_ZH = '警告'
RES_1556_EN = 'wrong'
RES_1556_ZH = '错误的'
RES_1630_EN = 'stopped'
RES_1630_ZH = '已停止'
RES_1631_EN = 'Because of no valid condition'
RES_1631_ZH = '因无有效 condition'
RES_1639_EN = 'default'
RES_1639_ZH = '缺省的'
RES_1716_EN = 'Task log report'
RES_1716_ZH = 'Task日志记录'
RES_1751_EN = 'request'
RES_1751_ZH = '请求'
RES_1816_EN = 'Because of one-time feature'
RES_1816_ZH = '因一次性类型'
RES_1827_EN = 'action log report'
RES_1827_ZH = '运行日志记录'
RES_1835_EN = 'real-time'
RES_1835_ZH = '实时'
RES_1873_EN = 'failed'
RES_1873_ZH = '失败'

def hello(payload, channel=None):
    return 'OK'


