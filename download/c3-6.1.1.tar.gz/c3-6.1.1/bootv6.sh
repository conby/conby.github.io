#!/bin/bash

# su hello
cd /home/hello/conby/c3-6.0.5
# python publish_hook.py --host www.conby.com -u hello --rand y --taskkey 666df240abc411e6ad99902b34399a93 --actionspec aa

nohup python runc3.py c3log.py 2 --host www.conby.com -u hello &
nohup python runc3.py c3lock.py 1 --host www.conby.com -u hello &
nohup python runc3.py c3api.py 2 --host www.conby.com -u hello &
nohup python runc3.py c3dataapi.py 2 --host www.conby.com -u hello &
nohup python runc3.py c3mail.py 1 --host www.conby.com -u hello &
nohup python runc3.py set2queue.py 1 --host www.conby.com -u hello &
nohup python runc3.py taskjob.py 2 --host www.conby.com -u hello &
nohup python runc3.py callbackevent.py 2 --host www.conby.com -u hello &
nohup python runc3.py minutelyclock.py 1 --host www.conby.com -u hello &
nohup python runc3.py c3clock.py 1 --host www.conby.com -u hello &
nohup python runc3.py ruletask.py 2 --host www.conby.com -u hello &
nohup python runc3.py hookevent.py 2 --host www.conby.com -u hello &
nohup python runc3.py pageevent.py 1 --host www.conby.com -u hello &
nohup python runc3.py tool4clean.py 1 --host www.conby.com -u hello &

# nohup python runc3.py set2spark.py 2 --host comatrix -u hello &
# nohup python runc3.py sql2spark.py 1 --host comatrix -u hello &
# nohup python runc3.py log2spark.py 1 --host comatrix -u hello &
# nohup python runc3.py log2spark.py 1 --host comatrix -u hello -f 1 &
# nohup python runc3.py log2spark.py 1 --host comatrix -u hello -f 2 &

#spark-submit --master yarn --deploy-mode cluster --driver-memory 2g --executor-memory 2g --num-executors 2 --jars $SPARK_HOME/lib/spark-streaming-kafka-assembly_2.10-1.6.1.jar,$SPARK_HOME/lib/spark-examples-1.6.1-hadoop2.6.0.jar,$SPARK_HOME/lib/mysql-connector-java-5.1.38-bin.jar,$SPARK_HOME/lib/datanucleus-api-jdo-3.2.6.jar,$SPARK_HOME/lib/datanucleus-core-3.2.10.jar,$SPARK_HOME/lib/datanucleus-rdbms-3.2.9.jar,$HIVE_HOME/lib/hive-hbase-handler-1.2.1.jar --py-files conby.zip --files $SPARK_HOME/conf/hive-site.xml,$SPARK_HOME/conf/log4j.properties,$HBASE_HOME/conf/hbase-site.xml c3streaming.py
#spark-submit --master yarn --deploy-mode cluster --driver-memory 2g --executor-memory 2g --num-executors 4 --jars $SPARK_HOME/lib/spark-streaming-kafka-assembly_2.10-1.6.1.jar,$SPARK_HOME/lib/spark-examples-1.6.1-hadoop2.6.0.jar,$SPARK_HOME/lib/mysql-connector-java-5.1.38-bin.jar,$SPARK_HOME/lib/datanucleus-api-jdo-3.2.6.jar,$SPARK_HOME/lib/datanucleus-core-3.2.10.jar,$SPARK_HOME/lib/datanucleus-rdbms-3.2.9.jar,$HIVE_HOME/lib/hive-hbase-handler-1.2.1.jar,$SPARK_HOME/lib/graphframes-0.1.0-spark1.6.jar --py-files conby.zip --files $SPARK_HOME/conf/hive-site.xml,$SPARK_HOME/conf/log4j.properties,$HBASE_HOME/conf/hbase-site.xml c3bigdata.py

