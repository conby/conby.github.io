<?php

	/**
	*
    *   @conby C3 SDK example code
	*
	*   Copyright 2004-2010 @conby C3 development team <support@conby.com>
	*
	*   Licensed under the Apache License, Version 2.0 (the "License");
	*   you may not use this file except in compliance with the License.
	*   You may obtain a copy of the License at
	*
	*       http://www.apache.org/licenses/LICENSE-2.0
	*
	*   Unless required by applicable law or agreed to in writing, software
	*   distributed under the License is distributed on an "AS IS" BASIS,
	*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*   See the License for the specific language governing permissions and
	*   limitations under the License.
	*
    *
    **/

require_once(dirname(__FILE__) .'/lib/c3_service.inc');

global $c3_user, $c3_passwd, $c3_cache_level;
global $c3_load_banlance_list;
$c3_load_banlance_list = array(); 
$c3_user = "demo";
$c3_passwd = "12345";
$c3_cache_level = 3600;

// load module from $_GET
if(isset($_GET['m']))
    using_c3_module($_GET['m']);

?>