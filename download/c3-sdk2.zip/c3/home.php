<?php

header('Location: c3/index.php');

?>