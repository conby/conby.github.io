<?php

	/**
	*
    *   @conby C3 SDK example code
	*
	*   Copyright 2004-2010 @conby C3 development team <support@conby.com>
	*
	*   Licensed under the Apache License, Version 2.0 (the "License");
	*   you may not use this file except in compliance with the License.
	*   You may obtain a copy of the License at
	*
	*       http://www.apache.org/licenses/LICENSE-2.0
	*
	*   Unless required by applicable law or agreed to in writing, software
	*   distributed under the License is distributed on an "AS IS" BASIS,
	*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*   See the License for the specific language governing permissions and
	*   limitations under the License.
	*
    *
    */

require_once(dirname(__FILE__) .'/lib/c3_service.inc');

global $c3_user, $c3_passwd, $c3_cache_level, $c3_service_node;
global $c3_load_banlance_list;
$c3_load_banlance_list = array(); 
$c3_user = "demo";
$c3_passwd = "12345";
$c3_cache_level = 3600;

// using c3 module, example 1
echo using_c3_module("hello", $username, $pass, 3600, true) . '<br>';
echo c3_hello('using cache example 1') . '<br>';

// using c3 module, example 2
echo using_c3_module("hello") . '<br>';
echo c3_hello('using cache example 2') . '<br>';

// call remote c3 service example
echo using_c3_module('tool') . '<br>';
echo c3_call_service('c3_echo',array('hello'=>'conby')) . '<br>';

// catch callback event and handle here
function c3_callback_handler($c3_task_key, $c3_callback_name, $c3_callback_type, $c3_callback_data) {
	// if($c3_callback_data == 'OK')
	//     dosomthing();
	// here there are 4 callback from hook condition, task action, hook task condition and hook task action
}
echo using_c3_module('user_tool') . '<br>';

// call remote BPA task service
// Warning: please remove "|" and example options, leave only one option

$callback_url = "http://". $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
$task_xml = 

"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" .
"<c3task name=\"every3minuteemail\" type=\"user|system|realtime\" description=\"every 3 minute email\">\n" .
"<c3conditions type=\"OR|AND\">\n" .
"  <c3condition name=\"e3minute\" type=\"cron|hook|due\" spec=\"*/3 * * * *\" payload=\"a=b\" eval=\"'[result]'=='OK'\">\n" .
"  </c3condition>\n" .
"  <c3condition name=\"name2\" type=\"action\" spec=\"action_name\" payload=\"\" eval=\"'[result]'=='OK'\">\n" .
"  </c3condition>\n" .
"  <c3condition name=\"name3\" type=\"post\" spec=\"http://a6.conby.com/action_name.do\" payload=\"\" eval=\"'[result]'=='OK'\">\n" .
"  </c3condition>\n" .
"</c3conditions>\n" .
"<c3actions>\n" .
"  <c3action name=\"callbackme\" type=\"http\" spec=\"" . $callback_url ."\" payload=\"c=test\">\n" .
"  </c3action>\n" .
"</c3actions>\n" .
"</c3task>";

echo using_c3_module('tool') . '<br>';
$task_key = c3_call_service('c3_create_task',array('description'=>$task_xml));
echo $task_key . '<br>';

$hook_task_key = c3_hook_task($task_key);   // default callback to this page
echo $hook_task_key . '<br>';

// remove these test tasks
echo c3_call_service('c3_update_task',array('description'=>'<c3task></c3task>','task_key'=>$task_key)) . '<br>';
echo c3_call_service('c3_update_task',array('description'=>'<c3task></c3task>','task_key'=>$hook_task_key)) . '<br>';

?>