<?php

	/**
	*
    *   @conby C3 SDK map-reduce API example code
	*
	*   Copyright 2004-2010 @conby C3 development team <support@conby.com>
	*
	*   Licensed under the Apache License, Version 2.0 (the "License");
	*   you may not use this file except in compliance with the License.
	*   You may obtain a copy of the License at
	*
	*       http://www.apache.org/licenses/LICENSE-2.0
	*
	*   Unless required by applicable law or agreed to in writing, software
	*   distributed under the License is distributed on an "AS IS" BASIS,
	*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*   See the License for the specific language governing permissions and
	*   limitations under the License.
	*
    *
    */


/**
 * c3_rss_mapper
 *
 * Basic map API for C3 RSS Map-Reduce services, offer RSS push event source service
 * Here is a simple example as C3 action:
 * <code>
 * 
 * Spec: c3_rss_mapper-c3_rss_reducer
 * Payload: http://news.google.com/news?cf=all&ned=us&hl=en&output=rss,http://news.163.com/special/00011K6L/rss_discovery.xml
 *
 * </code>
 * @link http://conby.com/services/post
 * @see C3 API library
 * @param array $post include $post['key'] as map item key
 * @return string as JSON format, this string will be passed to reduce API
 *
 */
function c3_rss_mapper($post) {

	$rss =  simplexml_load_file($post['key']);

	$items_array = array();
	$i = 10;
	foreach ($rss->channel->item as $item) {
		$item_array = array();
		$item_array[]= $item->title . '';
		$item_array[]= $item->link . '';
		$item_array[]= $item->pubDate . '';
		$items_array[] = $item_array;

		$i--;
		if($i==0)
			break;
	}

	return c3_json_encode($items_array);
}

/**
 * c3_rss_reducer
 *
 * Basic reduce API for C3 RSS Map-Reduce services, offer RSS push event source service
 * Here is a simple example as C3 action:
 * <code>
 * 
 * Spec: c3_rss_mapper-c3_rss_reducer
 * Payload: http://news.google.com/news?cf=all&ned=us&hl=en&output=rss,http://news.163.com/special/00011K6L/rss_discovery.xml
 *
 * </code>
 * @link http://conby.com/services/post
 * @see C3 API library
 * @param array $post include $post['reduce'] as reduce data
 * @return string as plain text format, this string will be passed to C3 callback hook
 *
 */
function c3_rss_reducer($post) { // task_key task_callback action_spec reduce

	$reducer_string = $post['reduce'];

	$rss_items_object = c3_json_decode($reducer_string);
	foreach($rss_items_object as $item) {
	    $hook_string = c3_json_encode($item);
		c3_update_hook_2($post, array('action_result'=>$hook_string,'mode'=>'a'));
	}

	return $reducer_string;
}

?>