<?php

require_once(dirname(__FILE__) .'/lib/c3_service.inc');

global $c3_user, $c3_passwd, $c3_cache_level, $c3_service_node;
global $c3_load_banlance_list;
$c3_load_banlance_list = array(); 
$c3_user = "demo";
$c3_passwd = "12345";
$c3_cache_level = 3600;

global $WC_TOKEN, $WC_APPID, $WC_APPSECRET;
$WC_TOKEN = 'abc123';
$WC_APPID = 'wxd58800fa8b18008c';
$WC_APPSECRET = '8288668808818128ea85b8809dd9eeb6';

// define user wechat logic
function c3_user_wechat($fromUsername, $toUsername, $time, $msgType, $keyword) {
	return 'c3 OK: ' . $keyword;
}

// import c3 wechat module
using_c3_module('test_wechat');
echo c3_echo_wechat(array());

?>
